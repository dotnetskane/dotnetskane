CREATE TABLE IF NOT EXISTS books
(
    id              uuid        DEFAULT uuid_generate_v4(),
    title           text        NOT NULL,
    author          text        NOT NULL,
    summary         text        NOT NULL,
    genre           text        NOT NULL,
    publish_year    integer,
    price           decimal     NOT NULL,
    CONSTRAINT pk_books_id PRIMARY KEY (id)
);

COMMENT
    ON TABLE books IS 'Books of all types';

COMMENT
    ON COLUMN books.id IS 'Unique identifier of the book';

COMMENT
    ON COLUMN books.title IS 'The title of the book';

COMMENT
    ON COLUMN books.author IS 'The author of the book';

COMMENT
    ON COLUMN books.summary IS 'A short summary or sales pitch for the book';

COMMENT
    ON COLUMN books.genre IS 'Genre, see genres table';

COMMENT
    ON COLUMN books.publish_year IS 'The year of when the book was first published';

COMMENT
    ON COLUMN books.price IS 'The price of the book';
