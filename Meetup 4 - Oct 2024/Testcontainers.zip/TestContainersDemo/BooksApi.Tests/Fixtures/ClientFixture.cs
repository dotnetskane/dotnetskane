﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;
using Testcontainers.PostgreSql;

namespace BooksApi.Tests.Fixtures;

/// <summary>
/// The <c>ClientFixture</c> class serves as a test fixture for initializing and configuring
/// a test instance of the web application. It extends <see cref="WebApplicationFactory{TEntryPoint}"/>,
/// enabling the creation of a pre-configured <see cref="HttpClient"/> for integration testing.
/// 
/// Implements <see cref="IAsyncLifetime"/> to handle asynchronous setup and cleanup tasks,
/// ensuring that necessary resources (e.g., test containers, database connections) are available
/// before tests run and properly disposed of afterward. Typically used as a shared fixture
/// across multiple test classes to avoid redundant initialization.
/// 
/// </summary>
public class ClientFixture : WebApplicationFactory<IApiMarker>, IAsyncLifetime
{
    internal DatabaseUtil DatabaseUtil { get; set; }

    internal HttpClient HttpClient{ get; set; }

    private readonly PostgreSqlContainer postgresContainer;

    internal string ConnectionString => $"Server={postgresContainer.Hostname};Port=5555;Database=booksdb;User Id=bookworm;Password=reader123;Pooling=false;Timeout=300;CommandTimeout=300";

    public ClientFixture()
    {
        postgresContainer = new PostgreSqlBuilder()
            .WithDatabase("booksdb")
            .WithUsername("bookworm")
            .WithPassword("reader123")
            .WithPortBinding(5555, 5432)
            .WithWaitStrategy(Wait.ForUnixContainer().UntilPortIsAvailable(5432))
            .Build();

        DatabaseUtil = new DatabaseUtil(ConnectionString);

        HttpClient = CreateClient();
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseSetting("ConnectionStrings:BooksDatabase", ConnectionString);
    }

    public async Task InitializeAsync()
    {
        await postgresContainer.StartAsync();
        await DatabaseUtil.SetupDatabaseAsync();
    }

    async Task IAsyncLifetime.DisposeAsync()
    {
        await postgresContainer.DisposeAsync();
    }
}
