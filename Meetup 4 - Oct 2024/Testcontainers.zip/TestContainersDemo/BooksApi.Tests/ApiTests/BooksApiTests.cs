using System.Net.Http.Json;

namespace BooksApi.Tests.ApiTests;

public class BooksApiTests : IClassFixture<ClientFixture>
{
    private readonly string baseUrl = "/v1/books";

    private readonly ClientFixture clientFixture;
    private readonly DatabaseUtil databaseUtil;
    private readonly HttpClient httpClient;

    public BooksApiTests(ClientFixture clientFixture)
    {
        this.clientFixture = clientFixture;
        databaseUtil = clientFixture.DatabaseUtil;
        httpClient = clientFixture.HttpClient;
    }
    
    [Fact(DisplayName = "GET /v1/books returns a list of BookResponses with status 200 OK")]
    public async Task GetBook_ReturnsListOfBookResponse_WithStatus200OK()
    {
        // Arrange
        var id = await databaseUtil.CreateBook();

        // Act
        var response = await httpClient.GetAsync(baseUrl);

        var books = HttpUtil.DeSerializeBody<IEnumerable<BookResponse>>(await response.Content.ReadAsStringAsync());

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        books.Should().Contain(book => book.Id == id);
    }

    [Fact(DisplayName = "GET /v1/books/{id} with an id that exists in the books table returns a single BookResponse with status 200 OK")]
    public async Task GetBook_ById_ReturnsSingleBookResponse_WithStatus200OK()
    {
        // Arrange
        var id = await databaseUtil.CreateBook();

        // Act
        var response = await httpClient.GetAsync($"{baseUrl}/{id}");

        var book = HttpUtil.DeSerializeBody<BookResponse>(await response.Content.ReadAsStringAsync());

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        book.Id.Should().Be(id);
    }

    [Fact(DisplayName = "PUT /v1/books/{id} with an id that exists in the books table and a new price returns a single BookResponse with status 200 OK")]
    public async Task UpdateBook_ById_ReturnsSingleBookResponse_WithStatus200OK()
    {
        // Arrange
        var id = await databaseUtil.CreateBook();
        var book = await databaseUtil.GetBookById(id);

        var bookRequest = new BookRequest
        {
            Author = book.Author,
            Title = book.Title,
            Genre = book.Genre,
            Summary = book.Summary,
            Year = book.Year,
            Price = 50,
        };

        // Act
        var response = await httpClient.PutAsJsonAsync($"{baseUrl}/{id}", bookRequest);

        // Assert
        var updatedBook = await databaseUtil.GetBookById(id);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        updatedBook.Price.Should().Be(50);
    }
}