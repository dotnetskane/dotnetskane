global using Xunit;
global using DotNet.Testcontainers.Builders;
global using Microsoft.AspNetCore.Hosting;
global using Microsoft.AspNetCore.Mvc.Testing;
global using Testcontainers.PostgreSql;
global using System.Text.Json.Serialization;
global using System.Text.Json;
global using System.Net;
global using Dapper;
global using FluentAssertions;
global using Npgsql;

global using BooksApi.Dtos;
global using BooksApi.Entities;
global using BooksApi.Tests.Fixtures;
global using BooksApi.Tests.Utils;
