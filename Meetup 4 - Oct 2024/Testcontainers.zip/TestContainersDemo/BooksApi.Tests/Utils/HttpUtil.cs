﻿namespace BooksApi.Tests.Utils;

public static class HttpUtil
{
    public static T DeSerializeBody<T>(string body)
    {
        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase) }
        };

        try
        {
            var result = JsonSerializer.Deserialize<T>(body, options);
            return result ?? default!;
        }
        catch
        {
            return default!;
        }
    }
}
