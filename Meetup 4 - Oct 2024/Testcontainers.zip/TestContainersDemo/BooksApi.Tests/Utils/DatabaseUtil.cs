﻿namespace BooksApi.Tests.Utils;

public class DatabaseUtil
{
    private readonly NpgsqlConnection connection;

    public DatabaseUtil(string connectionString)
    {
        DefaultTypeMap.MatchNamesWithUnderscores = true;
        connection = new NpgsqlConnection(connectionString);
    }

    internal async Task SetupDatabaseAsync()
    {
        await CreateExtensions();
        await CreateTableFromFile("books.sql");
    }

    internal async Task<Guid> CreateBook(string author = "J.R.R Tolkien", string title = "The Lord of the Rings", string genre = "Fantasy", int year = 1954, decimal price = 299)
    {
        var statement = "INSERT INTO books (author, title, summary, genre, publish_year, price) " +
            "VALUES (@Author, @Title, @Summary, @Genre, @Year, @Price) RETURNING id";
        return await connection.QuerySingleAsync<Guid>(statement,
            new
            {
                Author = author,
                Title = title,
                Summary = "Super good book",
                Genre = genre,
                Year = year,
                Price = price
            });
    }

    internal async Task<IEnumerable<BookRecord>> GetBooks()
    {
        var query = "SELECT * FROM books";
        return await connection.QueryAsync<BookRecord>(query);
    }

    internal async Task<BookRecord> GetBookById(Guid id)
    {
        var query = "SELECT * FROM books WHERE id = @Id";
        return await connection.QuerySingleOrDefaultAsync<BookRecord>(query, new { Id = id });
    }

    private async Task CreateExtensions() => await connection.ExecuteAsync(@"CREATE EXTENSION IF NOT EXISTS ""uuid-ossp"";");

    private async Task CreateTableFromFile(string fileName)
    {
        var sql = File.ReadAllText(@$"./Fixtures/Tables/{fileName}");
        await connection.ExecuteAsync(sql);
    }

}