# Overview
Solution containing two demo projects `TestContainerSampleApp` and `BooksApi`.
The purpose is to demonstrate both how Testcontainers are built and also how to use Testcontainer modules to spin up a temporary database for test purposes.

# TestContainerSampleApp
A simple console application demonstrating the use of [Testcontainers](https://github.com/testcontainers/testcontainers-dotnet) with the HelloWorld image. 
This app fetches and prints a GUID via an HTTP request to a Dockerized service, highlighting the setup, test execution, and cleanup handled by Testcontainers.

## Purpose
This sample aims to:
- Illustrate the container lifecycle and how Testcontainers integrates with Docker.
- Demonstrate how Docker Desktop shows the container lifecycle.
- Visualize the role of the daemon **Moby Ryuk**, which is used by Testcontainers to manage resource cleanup after tests.

# BooksApi & BooksApi.Tests

## BooksApi
A simple WebApp demonstrating the use of [Testcontainers](https://github.com/testcontainers/testcontainers-dotnet) and the module for Postgres.
- **Service & Repository Pattern**: Implements this pattern using interfaces to ensure a clear separation of concerns and facilitate testing.
- **Dapper as ORM**: Dapper is used for lightweight and efficient data access, providing a simple way to interact with the Postgres database.

## BooksApi.Tests
- **In-Memory Test Server**: Utilizes the `Microsoft.AspNetCore.Mvc.Testing` package to create an in-memory test server, enabling fast, isolated tests of API endpoints without the need for full server deployment.
- **Integration with Testcontainers**: Uses Testcontainers to spin up a Postgres container, allowing tests to run against a real database instance rather than mocks, enhancing test reliability.
- **FluentAssertions**: Adds expressive assertions to tests, making test code more readable.

## Git branches

- **mock**: Mocks the repository. Common solution when performing integration testing. Not using TestContainers
- **no-fixture**: No fixture is used, spins up one container per test case.
- **put-with-error**: There is an error in the update method in the BooksRepository. This is to show the value of TestContainers when working with databases.
- **main**: Complete solution with a ClassFixture so one container is used for all tests in the class instead of one container per test case.
