﻿namespace BooksApi;

public interface IApiMarker
{
}
