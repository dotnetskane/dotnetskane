﻿namespace BooksApi.Repositories;

public class BookRepository : IBookRepository
{
    private readonly NpgsqlConnection connection;

    public BookRepository(string connectionString)
    {
        DefaultTypeMap.MatchNamesWithUnderscores = true;
        connection = new NpgsqlConnection(connectionString);
    }

    public async Task<IEnumerable<BookRecord>> GetBooks() => await connection.QueryAsync<BookRecord>("SELECT * FROM books");

    public async Task<BookRecord> GetBookById(Guid id) => await connection.QuerySingleOrDefaultAsync<BookRecord>("SELECT * FROM books WHERE id = @Id", new { Id = id });

    public async Task<IEnumerable<BookRecord>> GetBooksByAuthor(string author) => await connection.QueryAsync<BookRecord>("SELECT * FROM books WHERE author = @Author", new { Author = author });

    public async Task<int> UpdateBook(Guid id, BookRecord bookRecord)
    {
        var query = "UPDATE books SET Title = @Title, Author = @Author, Price = @Price WHERE Id = @Id";
        return await connection.ExecuteAsync(query, new { Id = id, bookRecord.Title, Author = bookRecord.Author, Price = bookRecord.Price });
    }
}
