﻿namespace BooksApi.Interfaces;

public interface IBookService
{
    Task<IEnumerable<BookRecord>> GetBooks();

    Task<IEnumerable<BookRecord>> GetBooksByAuthor(string author);

    Task<BookRecord> GetBookById(Guid id);

    Task UpdateBook(Guid id, BookRecord bookRecord);

}
