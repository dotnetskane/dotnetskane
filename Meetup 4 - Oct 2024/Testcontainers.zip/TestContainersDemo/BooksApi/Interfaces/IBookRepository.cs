﻿namespace BooksApi.Interfaces;

public interface IBookRepository
{
    Task<IEnumerable<BookRecord>> GetBooks();

    Task<IEnumerable<BookRecord>> GetBooksByAuthor(string author);

    Task<BookRecord> GetBookById(Guid id);

    Task<int> UpdateBook(Guid id, BookRecord bookRecord);
}
