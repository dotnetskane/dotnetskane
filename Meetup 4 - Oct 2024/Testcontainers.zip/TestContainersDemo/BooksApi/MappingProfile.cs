﻿namespace BooksApi;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<BookRequest, BookRecord>();
        CreateMap<BookRecord, BookResponse>();
    }
}
