﻿namespace BooksApi.Exceptions;

public class GlobalExceptionHandler : IExceptionHandler
{
    private ILogger<GlobalExceptionHandler> logger { get; }

    public GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger)
    {
        this.logger = logger;
    }

    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        logger.LogError("An error occurred while processing your request: {Message}", exception.Message);

        ProblemDetails problemDetails = exception switch
        {
            RecordNotFoundException => new ProblemDetails
            {
                Status = (int)HttpStatusCode.NotFound,
                Type = exception.GetType().Name,
                Title = "Could not find what you are searching for",
                Detail = exception.Message
            },

            _ => new ProblemDetails
            {
                Status = (int)HttpStatusCode.InternalServerError,
                Type = exception.GetType().Name,
                Title = "An unexpected exception occurred",
                Detail = exception.Message
            }
        };

        httpContext.Response.StatusCode = (int)problemDetails.Status!;

        await httpContext
            .Response
            .WriteAsJsonAsync(problemDetails, cancellationToken);

        return true;
    }
}

