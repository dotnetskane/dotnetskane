﻿namespace BooksApi.Services;

public class BookService : IBookService
{
    private readonly IBookRepository bookRepository;

    public BookService(IBookRepository bookRepository)
    {
        this.bookRepository = bookRepository;
    }

    public async Task<BookRecord> GetBookById(Guid id)
    {
        var result = await bookRepository.GetBookById(id);
        return result ?? throw new RecordNotFoundException("Could not find the book with the given identifier");
    }

    public async Task<IEnumerable<BookRecord>> GetBooks() => await bookRepository.GetBooks();

    public async Task<IEnumerable<BookRecord>> GetBooksByAuthor(string author) => await bookRepository.GetBooksByAuthor(author);

    public async Task UpdateBook(Guid id, BookRecord bookRecord)
    {
        var updated = await bookRepository.UpdateBook(id, bookRecord);
        if (updated == 0) {
            throw new RecordNotFoundException("Could not find the book with the given identifier");
        }
    }
}
