﻿namespace BooksApi.Entities;

public class BookRecord
{
    public Guid? Id { get; set; }

    public required string Title { get; set; }

    public required string Author { get; set; }

    public string? Summary { get; set; }

    public string? Genre { get; set; }

    public int Year { get; set; }

    public decimal Price { get; set; }
}
