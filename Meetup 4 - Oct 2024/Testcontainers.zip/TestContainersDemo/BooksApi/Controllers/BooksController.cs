using BooksApi.Repositories;

namespace BooksApi.Controllers;

[ApiController]
[Route("v1/[controller]")]
public class BooksController : ControllerBase
{
    private readonly IBookService bookService;
    private readonly IMapper mapper;

    public BooksController(IMapper mapper, IBookService bookService)
    {
        this.mapper = mapper;
        this.bookService = bookService;
    }

    /// <summary>
    /// Get a list of all books.
    /// </summary>
    /// <returns>List of books</returns>
    /// <response code="200">Returns the list of books</response>
    /// <response code="500">If an internal error occurs</response>    [HttpGet(Name = "GetBooks")]
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<BookResponse>), 200)]
    [ProducesResponseType(500)]
    public async Task<IActionResult> GetBooks(string? author)
    {
        var result = author == null ? await bookService.GetBooks() : await bookService.GetBooksByAuthor(author);
        return Ok(mapper.Map<IEnumerable<BookResponse>>(result));
    }

    /// <summary>
    /// Get a specific book by ID.
    /// </summary>
    /// <returns>A book with the given identifier</returns>
    /// <response code="404">If the book is not found</response>
    /// <response code="500">If an internal error occurs</response>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(BookResponse), 200)]
    [ProducesResponseType(500)]
    public async Task<IActionResult> GetBookById(Guid id)
    {
        var result = await bookService.GetBookById(id);
        return Ok(mapper.Map<BookResponse>(result));
    }

    /// <summary>
    /// Updates a specific book by it's ID.
    /// </summary>
    /// <response code="200">If the update was successful</response>
    /// <response code="404">If the book is not found</response>
    /// <response code="500">If an internal error occurs</response>
    [HttpPut("{id:guid}")]
    public async Task<IActionResult> UpdateBook(Guid id, [FromBody] BookRecord bookRecord)
    {
        await bookService.UpdateBook(id, bookRecord);
        return Ok();
    }

}
